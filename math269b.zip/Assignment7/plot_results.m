plot(uExact001(:,2), 'red');
hold on
plot(uComp001(:,2));