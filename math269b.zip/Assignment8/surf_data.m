close all
surf(uExact000);
hold on
surf(uExact001);
surf(uExact002);
surf(uExact003);
surf(uExact004);
surf(uExact005);
surf(uExact006);
surf(uExact007);
surf(uExact008);
surf(uExact009);
surf(uExact010);
figure;
surf(uComp000);
hold on
surf(uComp001);
surf(uComp002);
surf(uComp003);
surf(uComp004);
surf(uComp005);
surf(uComp006);
surf(uComp007);
surf(uComp008);
surf(uComp009);
surf(uComp010);