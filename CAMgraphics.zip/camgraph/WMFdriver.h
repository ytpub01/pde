#ifndef __WMFDRIVER__
#define __WMFDRIVER__
//
//##############################################################################
//                             WMFdriver.h
//##############################################################################
//
//  Creates a metafile containing the output from calls to the graphics
//  routines specified by the UCdriver base class.
//
//  Note : Because of the restrictions associated with the use of 
//         windows metafiles, one must access the windows metafile
//         generated for a particular frame using the getWMFframe()
//         method. This method returns a pointer to a WMFframe instance 
//         from which a handle to the metafile can be extracted.
//
//         After a call to getWMFframe() subsequent plotting calls are
//         plotted in a new windows metafile. 
//
//         The WMFframe instance must be explicitly deleted after use,
//         otherwise the memory that stores its associated metafile 
//         will not be released.
// 
//         The frame() method of this driver is "empty"
//
//##############################################################################
//
//  Using the metafile created by this driver : 
//
//  The metafile created by this driver uses a logical device with a
//  maximal coordinate of  maxLogicalCoordinate. In playing a metafile
//  constructed by this driver, one must account for this logical device 
//  size by setting the window extent of the device used to play the meta file. 
//  
//  Here is sample code that illustrates playing this meta-file,
//
/*
void DisplayObject::OnPaint() 
{
//
//  metaDisplaySize : Size (in logical units) used to create the metafile
//                    (A data member that is set before the call, typically
//                    obtained by invoking getMaxLogicalCoordinate() for a
//                    WMFframe instance.)
//
//  metaFileHandle  : Handle to metafile to be played. 
//                    (A data member that is set before the call, typically
//                    obtained by invoking the getMetaFileHandle() for a
//                    WMFframe intance.) 
//

    if(metaFileHandle == 0) return;  // return if there is no meta file to 
                                     // display

	CPaintDC dc(this); // device context for painting
//
//  Set scaling : map metaDisplaySize X metaDisplaySize to 
//  number of pixes in the viewing screen  use isotropic scaling 
//
	CRect rect;
	GetClientRect(rect);

    dc.SetMapMode(MM_ISOTROPIC);

    CSize cs1(metaDisplaySize,metaDisplaySize);
    dc.SetWindowExt (cs1);

    CSize cs2(rect.right    - rect.left,rect.bottom   - rect.top);
    dc.SetViewportExt(cs2);
//
//  play the meta file
//
    dc.PlayMetaFile(metaFileHandle);
}

*/
//
// Chris Anderson 4/18/99 (C) UCLA
//##############################################################################
//
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef WINVER
#define WINVER  0x0500   // Define WINVER so the Visual Studio .net doesn't complain
#endif 

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afx.h>
#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions

#include "ucdriver.h"
#include "WMFframe.h"

class WMFdriver : public UCdriver
{
    //  Base Class UCdriver Implementations

    public : 
    
    virtual void lines(double *x, double *y, long npoints, int dash_pattern,
             unsigned user_pattern, double width, int color, double *rgb);
 
    virtual void line(double x1, double y1, double x2, double y2, int dash_pattern, 
             unsigned user_pattern, double width, int color, double *rgb); 

    virtual void point(double x, double y, char p, char *font, double size,
             int color, double *rgb);
    virtual void points(double *X, double *Y, long np, char p, char *font,
              double size, int color, double *rgb);

    virtual void text(double x, double y, char *s, char *font, double size,
            double rotation, double horiz_just, double vert_just,
            int color, double *rgb);

    virtual void region(double *X, double *Y, long npoints, double *RGB);

    virtual void frame();

    public :

    WMFdriver();
    virtual ~WMFdriver();

    WMFframe* getWMFframe();    
    int getMaxLogicalCoordinate(){return maxLogicalCoordinate;};
    
     
    protected :


    CMetaFileDC* pDC;
    CMetaFileDC* fontDC;

    void createMetaFile();
    void drawBoundingBox();
//
//  thick line dashing
//
    int dashCall;

    void    initializeGetNextElement();
    double  getNextElementSize(int dash_pattern);
    void    dashlines(double* x, double* y, int n, int dash_pattern, char user_pattern,
             double width, int color, double* rgb);
//
//  Color translation 
//
    COLORREF getColorRef(int iColor);

//
//  Brush caching variables
//
    CBrush*         localBrush;
    CBrush*      originalBrush;
    double    localBrushRGB[3];

    void restoreBrush();
    void setLocalBrush(double* rgb);
//
//  Pen caching variables
//
    CPen*        localPen;
    CPen*     originalPen;

    double     localWidth;
    int        localColor;
    int         localDash;
    double    localRGB[3];
 
    void setLocalPen(double width, int dash_pattern, int color, double* rgb);
    void restorePen();
//
//  Font caching variables
//
    CFont*               localF;
    CFont*            originalF;

    int          localFRotation;
    int            localFHeight;
    char        localFName[256];

    void setTextFont(int Fheight, int Frotation, char* Ffont);
    void restoreFont();

    static  char* defaultFont;
    static  int   defaultFontHeight;
    static  int maxLogicalCoordinate;
//
//
//


};
#endif

