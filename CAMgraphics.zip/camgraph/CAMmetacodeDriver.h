#ifndef __CAMMETADRIVER__
#define __CAMMETADRIVER__
//
//######################################################################
//
//            Chris Anderson (C) UCLA
//
//                 Sept. 20, 1996
//
//######################################################################
//
//
//
#include "CAMgraphicsDriver.h"
#include "fstream.h"

#ifndef __CAMPLOTARGUMENTS__
class CAMplotArguments;
#endif

#ifndef __CAMCONTOURARGUMENTS__
class CAMcontourArguments;
#endif

#ifndef __CAMSURFACEARGUMENTS__
class CAMsurfaceArguments;
#endif

#ifndef __CAMTEXTARGUMENTS__
class CAMTextArguments;
#endif

#ifndef __CAMSETARGUMENTS__
class CAMsetArguments;
#endif

#include "camgraphimpexp.h"


class __IMPEXP__ CAMmetacodeDriver : public CAMgraphicsDriver
{

public  :

	CAMmetacodeDriver();
    CAMmetacodeDriver(char* F);
    ~CAMmetacodeDriver();
    
	void open();
	void close();
	void frame();
	void accept(const CAMplotArguments& A);
	void accept(const CAMcontourArguments& A);
	void accept(const CAMsurfaceArguments& A);
	void accept(const CAMtextArguments& A);
 	void accept(const CAMsetArguments& A);


private :


   ofstream fout;
   char* outputFile;

};
#endif