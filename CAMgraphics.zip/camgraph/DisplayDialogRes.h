#define  IDD_DIALOG1                    101
#define  IDC_BUTTON1                   1000
#define  IDC_BUTTON2                   1001

