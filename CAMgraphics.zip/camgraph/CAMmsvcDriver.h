#ifndef __CAMMSVCDRIVER__
#define __CAMMSVCDRIVER__
//
//######################################################################
//
//            Chris Anderson (C) UCLA
//
//             April, 4, 1999
//
//######################################################################
//
//
//

#include "CAMgraphicsDriver.h"

#ifndef __MSVCconsoleDriver__
class MSVCconsoleDriver;
#endif

#ifndef __CAMPLOTARGUMENTS__
class CAMplotArguments;
#endif

#ifndef __CAMCONTOURARGUMENTS__
class CAMcontourArguments;
#endif

#ifndef __CAMSURFACEARGUMENTS__
class CAMsurfaceArguments;
#endif

#ifndef __CAMTEXTARGUMENTS__
class CAMtextArguments;
#endif

#ifndef __CAMSETARGUMENTS__
class CAMsetArguments;
#endif

#ifndef _CAMGRAPHICS_
class CAMgraphicsState;
class CAMgraphics;
#endif

#include "camgraphimpexp.h"

class __IMPEXP__ CAMmsvcDriver : public CAMgraphicsDriver
{

public  :

	CAMmsvcDriver();
    ~CAMmsvcDriver();
    
	void open();
	void close();
	void frame();
	void accept(const CAMplotArguments& A);
	void accept(const CAMcontourArguments& A);
	void accept(const CAMsurfaceArguments& A);
	void accept(const CAMtextArguments& A);
 	void accept(const CAMsetArguments& A);


private :

   CAMgraphics* G;
   CAMgraphicsState* S;
   MSVCconsoleDriver* Mdriver;


};
#endif