#ifndef __MSVCconsoleDriver__
#define __MSVCconsoleDriver__
//
//##############################################################################
//                        MSVCconsoleDriver.h 
//##############################################################################
//
//  A driver implementing the methods specified by the UCdriver base class.
//
//  All but the frame() method are inherited from the WMFdriver class that creates
//  a windows metafile containing the output of any graphics calls. This class merely
//  overrides the frame() method so that the metafile is played into a modal dialog. 
//
//  Because of the use of a modal dialog to display graphics output
//  this driver requires :
//
//  (*) The multi-thread runtime library be used 
//
//  (*) The users code be contained within a routine with signature
//
//       int CAMmain(int argc, char* argv[])
//
//  (*) The users code linked to a library containing  CAMstartup.obj, 
//      DisplayDialog.obj, WMFdriver.obj.
//
//  (*) The file DisplayDialog.rc be contained in the users project. 
//      
//
//  Chris Anderson 4/18/99 (C) UCLA
//##############################################################################
//
#include "WMFdriver.h"
#include <afxcmn.h>			   // MFC support for Windows Common Controls

class MSVCconsoleDriver : public WMFdriver
{
public:

	MSVCconsoleDriver();
	~MSVCconsoleDriver();
    
    void frame();

    void setCurrentDisplayBounds(int x, int y, int cx, int cy)
    {displayX = x; displayY =y; displayCX = cx; displayCY = cy;};

    void getCurrentDisplayBounds(int& x, int& y, int& cx, int& cy)
    {x = displayX; y = displayY; cx = displayCX; cy = displayCY;}

    private :
//
//  caching of display bounds
//
    int displayX;
    int displayY;
    int displayCX;
    int displayCY;
};

#endif 