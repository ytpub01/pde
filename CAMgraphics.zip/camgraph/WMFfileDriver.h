#ifndef __WMFfileDriver__
#define __WMFfileDriver__
//
//##############################################################################
//                        WMFfileDriver.h 
//##############################################################################
//
//  A driver implementing the methods specified by the UCdriver base class.
//
//  All but the frame() method are inherited from the WMFdriver class that creates
//  a windows metafile containing the output of any graphics calls. This class merely
//  overrides the frame() method so that the metafile is written to a file. 
//
//  Chris Anderson 8/3/99 (C) UCLA
//##############################################################################
//
#include "WMFdriver.h"
#include <afxcmn.h>			   // MFC support for Windows Common Controls

class WMFfileDriver : public WMFdriver
{
public:

	WMFfileDriver();
	~WMFfileDriver();
    
    void frame();

    void setCurrentDisplayBounds(int x, int y, int cx, int cy)
    {displayX = x; displayY =y; displayCX = cx; displayCY = cy;};

    void getCurrentDisplayBounds(int& x, int& y, int& cx, int& cy)
    {x = displayX; y = displayY; cx = displayCX; cy = displayCY;}

    private :
//
//  caching of display bounds
//
    int displayX;
    int displayY;
    int displayCX;
    int displayCY;
};

#endif 