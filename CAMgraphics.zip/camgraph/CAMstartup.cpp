#include <iostream>
using namespace std;

#include "MSVCconsoleDriver.h"
//
//##############################################################################
//                             CAMstartup.cpp
//##############################################################################
//
// A very simple wrapper applications that initializes the MFC class structure 
// and then call a users program whose signature is
//
// int CAMmain(int argc, char* argv[])
//
//
// Chris Anderson (4/18/99)
//
// Changes Made : Added arc and argv to CAMmain 5/1/99
//##############################################################################
//
 
CWinApp theApp;

int CAMmain(int argc, char* argv[]);

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
	    return CAMmain(argc, argv);
	}

	return nRetCode;
}
